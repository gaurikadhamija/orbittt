import React from 'react';
import { useOrbit } from '../context/OrbitContext';
import { truncateAddress } from '../utils/crypto';
import {
  Wallet,
  ArrowRight,
  ShieldCheck,
  QrCode,
  Sparkles,
  Lock,
  Layers,
  CheckCircle2,
} from 'lucide-react';

interface LandingHeroProps {
  onNavigate: (tab: 'landing' | 'dashboard' | 'passport' | 'explorer', objectId?: string) => void;
  onOpenRegister: () => void;
  onOpenScanner: () => void;
  onOpenConnectWallet: () => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onNavigate,
  onOpenRegister,
  onOpenScanner,
  onOpenConnectWallet,
}) => {
  const { currentWallet, walletStatus, objects } = useOrbit();
  const isConnected = walletStatus === 'connected';

  return (
    <div className="w-full">
      {/* 1. Main Hero: Asymmetric Two-Column Layout (Matching the user's reference image) */}
      <section className="relative overflow-hidden py-12 sm:py-20 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            
            {/* Left Column: Brand & Mission (Inspired by SheVibes hero text) */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
              {/* Event / Protocol Pill Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1e0728]/90 border border-pink-500/30 text-xs font-semibold text-pink-200 shadow-lg shadow-pink-950/40">
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-pulse" />
                <span className="tracking-wide uppercase text-[11px] font-mono font-bold text-pink-300">
                  ORBIT PROTOCOL · WEB3 PHYSICAL REGISTRY
                </span>
              </div>

              {/* Stylized Headline */}
              <div className="space-y-3">
                <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-200 via-rose-300 to-pink-500 tracking-tight leading-[1.05] drop-shadow-sm">
                  ORBIT
                </h1>

                <p className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-tight">
                  Objects Made for <span className="italic font-serif text-pink-300">Reality</span>. Provenance Made by <span className="italic font-serif text-pink-400">Blockchain</span>.
                </p>
              </div>

              {/* Editorial Subtitle */}
              <p className="text-sm sm:text-base text-pink-100/70 max-w-xl font-normal leading-relaxed italic font-serif">
                A decentralized physical passport where luxury cameras, laptops, and bicycles meet immutable multi-owner history, verified repair credentials, and privacy-shielded escrow recovery.
              </p>

              {/* CTA Buttons Row */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onOpenConnectWallet}
                  className="flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-black tracking-wide uppercase text-white bg-gradient-to-r from-[#d94680] via-[#c2336e] to-[#a81e55] hover:from-[#e0528c] hover:to-[#b82560] rounded-full shadow-xl shadow-pink-600/35 border border-pink-400/40 transition-all cursor-pointer hover:scale-105 active:scale-95"
                >
                  <Wallet className="w-4 h-4 text-white stroke-[2.5]" />
                  <span>{isConnected ? `Dashboard (${truncateAddress(currentWallet.address)})` : 'Connect Web3 Wallet'}</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>

                <button
                  onClick={onOpenScanner}
                  className="flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-bold text-pink-200 bg-[#1e0726]/80 hover:bg-[#2c0b38] border border-pink-500/30 hover:border-pink-400/50 rounded-full transition-all cursor-pointer shadow-lg shadow-black/40"
                >
                  <QrCode className="w-4 h-4 text-pink-400" />
                  <span>Scan Physical Tag</span>
                </button>
              </div>

              {/* Micro Status */}
              <div className="flex items-center gap-2 text-xs font-mono text-pink-300/80 pt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>Smart Contract Network: Sepolia Testnet · Zero PII Finder Relay</span>
              </div>
            </div>

            {/* Right Column: Warm Blush-Cream Registration Card (Direct reproduction of the reference card style) */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl bg-gradient-to-b from-[#fdf2ec] via-[#fae8dd] to-[#f7ddcf] p-6 sm:p-8 shadow-2xl shadow-pink-950/60 border border-pink-200/60 text-[#290a30] transition-all hover:shadow-pink-900/40">
                {/* Top Badge: REGISTRATION · LIVE */}
                <div className="flex items-center justify-between border-b border-pink-200/70 pb-4 mb-6">
                  <span className="text-xs font-black tracking-widest uppercase text-[#541a5f] font-mono">
                    REGISTRATION & RECOVERY
                  </span>
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold tracking-wider text-pink-700 bg-pink-100/90 border border-pink-300/80">
                    LIVE
                  </span>
                </div>

                {/* Dual Stats Row (matches 804+ / 2-4 boxes in reference image) */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="p-4 rounded-2xl bg-white/70 border border-pink-200/80 shadow-sm">
                    <div className="text-2xl sm:text-3xl font-black text-[#290a30]">
                      804+
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-pink-900/70 mt-1">
                      OBJECTS REGISTERED
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/70 border border-pink-200/80 shadow-sm">
                    <div className="text-2xl sm:text-3xl font-black text-[#290a30]">
                      100%
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-pink-900/70 mt-1">
                      ESCROW SECURED
                    </div>
                  </div>
                </div>

                {/* Wide Berry Button (matching Register Now button in reference) */}
                <button
                  onClick={onOpenRegister}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl text-sm font-black tracking-wide text-white bg-gradient-to-r from-[#c83771] to-[#b02960] hover:from-[#d94680] hover:to-[#be2b65] transition-all shadow-xl shadow-pink-800/30 cursor-pointer active:scale-98"
                >
                  <span>Register Physical Object Now</span>
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </button>

                {/* Sub-banner link (matching "Direct entry to AM Web3 community" in reference) */}
                <div className="mt-4 p-3 rounded-xl bg-pink-100/70 border border-pink-200 flex items-center justify-center gap-2 text-xs font-bold text-pink-900">
                  <Sparkles className="w-3.5 h-3.5 text-pink-600 fill-pink-500" />
                  <span>Direct entry to Smart Escrow & Tamper-Proof Tagging</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Core Pillars (Deep velvet plum panels with rose borders) */}
      <section className="py-14 sm:py-20 border-t border-pink-500/20 bg-[#0e0314]/80 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center space-y-2">
            <span className="text-xs font-mono font-bold text-pink-400 uppercase tracking-widest">
              ARCHITECTURE & VERIFICATION
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
              Built for Physical High-Value Assets
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* 1. Digital Identity */}
            <div className="p-6 rounded-3xl bg-[#180620]/80 border border-pink-500/20 hover:border-pink-400/50 transition-all space-y-4 shadow-xl shadow-black/40 group">
              <div className="w-12 h-12 rounded-2xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🏷️
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">
                Tamper-Proof Hardware Seals
              </h3>
              <p className="text-xs sm:text-sm text-pink-100/70 leading-relaxed">
                Physical serial numbers are cryptographically hashed and bound to on-chain tokens. Durable laser-etched QR tags link the device directly to its immutable passport.
              </p>
            </div>

            {/* 2. Ownership History */}
            <div className="p-6 rounded-3xl bg-[#180620]/80 border border-pink-500/20 hover:border-pink-400/50 transition-all space-y-4 shadow-xl shadow-black/40 group">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🔗
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">
                Verifiable Ownership History
              </h3>
              <p className="text-xs sm:text-sm text-pink-100/70 leading-relaxed">
                Immutable timeline tracking <strong className="text-pink-200">Owner A → Owner B → Owner C</strong> plus certified laboratory service repairs with zero guesswork.
              </p>
            </div>

            {/* 3. Lost Object Recovery */}
            <div className="p-6 rounded-3xl bg-[#180620]/80 border border-pink-500/20 hover:border-pink-400/50 transition-all space-y-4 shadow-xl shadow-black/40 group">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🛡️
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">
                Zero-PII Lost Item Escrow
              </h3>
              <p className="text-xs sm:text-sm text-pink-100/70 leading-relaxed">
                When items are lost, finders scan the tag without seeing the owner's private personal information. Smart contract escrow bounties release upon physical return.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Featured Hardware Passports Showcase */}
      <section className="py-14 bg-gradient-to-r from-[#17051f]/90 via-[#23082c]/80 to-[#17051f]/90 border-t border-b border-pink-500/20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-pink-400">
                  LIVE HARDWARE PASSPORTS ({objects.length})
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
                Explore Verified Cryptographic Passports
              </h3>
            </div>

            <button
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-pink-300 hover:text-white bg-[#1e0726]/80 border border-pink-500/30 hover:border-pink-400/60 rounded-full transition-all self-start sm:self-auto cursor-pointer"
            >
              <span>View All Passports ({objects.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {objects.slice(0, 4).map(item => (
              <div
                key={item.id}
                onClick={() => onNavigate('passport', item.id)}
                className="group p-3.5 rounded-2xl bg-[#180622]/90 border border-pink-500/20 hover:border-pink-400/50 transition-all cursor-pointer shadow-lg shadow-black/40 hover:scale-[1.02] flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-32 w-full rounded-xl overflow-hidden bg-[#120419] mb-3">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/75 backdrop-blur-sm text-[10px] font-mono font-bold text-pink-300 border border-pink-500/30">
                      {item.orbitId}
                    </div>
                    {item.status === 'LOST' && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-rose-950/80 border border-rose-500 text-[10px] font-bold text-rose-300">
                        LOST
                      </div>
                    )}
                  </div>

                  <div className="text-[10px] font-mono text-pink-300/70">{item.brand}</div>
                  <h4 className="text-xs font-bold text-white group-hover:text-pink-300 transition-colors truncate mt-0.5">
                    {item.name}
                  </h4>
                </div>

                <div className="mt-3 pt-2.5 border-t border-pink-500/15 flex items-center justify-between text-[11px]">
                  <span className="text-pink-200/60 font-mono text-[10px] truncate max-w-[110px]">
                    {item.serialNumber}
                  </span>
                  <span className="font-bold text-pink-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Passport →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
