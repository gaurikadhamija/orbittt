import React from 'react';

/**
 * Compact MetaMask-style fox mark (inline SVG, no network request).
 * Swap the paths for the official asset from https://metamask.io/brand-resources if brand-exact artwork is required.
 */
export const MetaMaskLogo: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 32 30" className={className} role="img" aria-label="MetaMask" xmlns="http://www.w3.org/2000/svg">
    <path d="M29.4 1 17.8 9.6l2.1-5.1z" fill="#E2761B" stroke="#E2761B" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m2.6 1 11.5 8.7-2-5.2zM25.2 21.6l-3.1 4.7 6.6 1.8 1.9-6.4zM1.5 21.7l1.9 6.4 6.6-1.8-3.1-4.7z" fill="#E4761B" stroke="#E4761B" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m9.7 13.1-1.8 2.8 6.5.3-.2-7zM22.3 13.1l-4.5-4-.1 7.1 6.5-.3zM10 26.3l3.9-1.9-3.4-2.6zM18.1 24.4l3.9 1.9-.5-4.5z" fill="#E4761B" stroke="#E4761B" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m22 26.3-3.9-1.9.3 2.600v1.100zM10 26.3l3.6 1.800v-1.100l.3-2.600z" fill="#D7C1B3" stroke="#D7C1B3" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m13.700 19.800-3.200-.9 2.300-1.100zM18.300 19.800l.9-2 2.300 1.100z" fill="#233447" stroke="#233447" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m10 26.300.5-4.700-3.600.1zM21.500 21.600l.5 4.700 3.100-4.600zM24 15.900l-6.500.3.600 3.600.9-2 2.300 1.100zM10.500 18.900l2.300-1.100.9 2 .6-3.600-6.500-.3z" fill="#CD6116" stroke="#CD6116" strokeWidth=".3" strokeLinejoin="round" />
    <path d="m7.900 15.900 2.700 5.300-.1-2.600zM21.600 18.600l-.1 2.600 2.700-5.300zM14.400 16.200l-.6 3.600.8 4 .2-5.300zM17.500 16.200l-.3 2.300.2 5.300.8-4z" fill="#E4751F" stroke="#E4751F" strokeWidth=".3" strokeLinejoin="round" />
  </svg>
);
