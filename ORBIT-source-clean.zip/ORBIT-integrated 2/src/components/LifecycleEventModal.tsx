import React, { useState } from 'react';
import { useOrbit } from '../context/OrbitContext';
import { PhysicalObject } from '../types/orbit';
import { X, Wrench, ShieldCheck, FileCheck, CheckCircle2 } from 'lucide-react';

interface LifecycleEventModalProps {
  object: PhysicalObject | null;
  isOpen: boolean;
  onClose: () => void;
  onEventLogged: () => void;
}

export const LifecycleEventModal: React.FC<LifecycleEventModalProps> = ({
  object,
  isOpen,
  onClose,
  onEventLogged,
}) => {
  const { recordLifecycleEvent, currentWallet } = useOrbit();

  const [eventType, setEventType] = useState<'REPAIR_RECORDED' | 'MAINTENANCE' | 'CERTIFIED_INSPECTION'>('REPAIR_RECORDED');
  const [title, setTitle] = useState('');
  const [serviceCenter, setServiceCenter] = useState(
    currentWallet.name.includes('TechFix') ? currentWallet.name : 'Authorized Service Center'
  );
  const [componentsReplaced, setComponentsReplaced] = useState('');
  const [invoiceHash, setInvoiceHash] = useState('');
  const [costEth, setCostEth] = useState('0.04');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen || !object) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) {
      alert('Please fill in event title and service notes.');
      return;
    }

    setIsSubmitting(true);
    try {
      const parts = componentsReplaced
        ? componentsReplaced.split(',').map(s => s.trim()).filter(Boolean)
        : undefined;

      const ok = await recordLifecycleEvent(object.id, {
        type: eventType,
        title,
        description,
        serviceCenter,
        invoiceHash: invoiceHash || `INV-${Date.now().toString().slice(-6)}`,
        componentsReplaced: parts,
        costEth,
      });

      if (ok) {
        onEventLogged();
        onClose();
      }
    } catch (err) {
      console.error(err);
      alert('Failed to log event');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Wrench className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Record Service or Repair</h2>
              <p className="text-xs text-slate-400">
                Log tamper-resistant lifecycle event to {object.orbitId} timeline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
          {/* Event Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Lifecycle Event Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'REPAIR_RECORDED', label: 'Authorized Repair', icon: Wrench },
                { id: 'MAINTENANCE', label: 'Tune-up / Service', icon: FileCheck },
                { id: 'CERTIFIED_INSPECTION', label: 'Appraisal / METAS', icon: ShieldCheck },
              ].map(t => {
                const Icon = t.icon;
                return (
                  <button
                    type="button"
                    key={t.id}
                    onClick={() => {
                      setEventType(t.id as any);
                      if (!title) {
                        if (t.id === 'REPAIR_RECORDED') setTitle('Component Repair & Calibration');
                        if (t.id === 'MAINTENANCE') setTitle('Scheduled Preventative Service');
                        if (t.id === 'CERTIFIED_INSPECTION') setTitle('Certified Authenticity Inspection');
                      }
                    }}
                    className={`p-2.5 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                      eventType === t.id
                        ? 'bg-blue-950/50 border-blue-500 text-blue-300 font-semibold'
                        : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 mb-1 text-cyan-400" />
                    <div className="leading-tight">{t.label}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Event Title *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Ultrasonic Sensor Cleaning & Shutter Replaced"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Service Center & Cost */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Authorized Service Provider
              </label>
              <input
                type="text"
                placeholder="e.g. TechFix Pro Labs Wetzlar"
                value={serviceCenter}
                onChange={e => setServiceCenter(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Service Cost (ETH)
              </label>
              <input
                type="number"
                step="0.001"
                value={costEth}
                onChange={e => setCostEth(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs sm:text-sm text-white font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Components Replaced */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Components Replaced or Serviced (Comma Separated)
            </label>
            <input
              type="text"
              placeholder="e.g. Rangefinder Prism Seal, Battery Contact, O-Ring"
              value={componentsReplaced}
              onChange={e => setComponentsReplaced(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Detailed Work Description & Verification Notes *
            </label>
            <textarea
              rows={3}
              required
              placeholder="Detailed technical overview of work performed, calibration results, test tolerances..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="text-xs text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-blue-400 to-cyan-300 hover:from-blue-300 hover:to-cyan-200 rounded-lg transition-all shadow-md shadow-blue-500/20 cursor-pointer"
            >
              {isSubmitting ? 'Recording on Chain...' : 'Sign & Add to Blockchain Timeline'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
