import { ethers } from 'ethers';
import { PhysicalObject, TimelineEvent } from '../types/orbit';

/**
 * Creates a deterministic, canonical representation of important passport data.
 * Excludes transient UI state and non-essential personal information.
 * Uses strict key ordering and normalized values so that identical passport data
 * will always produce the exact same canonical string across platforms.
 */
export function createCanonicalPassportPayload(obj: PhysicalObject): string {
  // Deterministically sort and format lifecycle events
  const sortedEvents = [...(obj.timeline || [])].sort((a, b) => {
    const timeDiff = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    if (timeDiff !== 0) return timeDiff;
    return (a.id || '').localeCompare(b.id || '');
  });

  const canonicalEvents = sortedEvents.map((evt: TimelineEvent) => ({
    actorAddress: (evt.actorAddress || '').trim().toLowerCase(),
    blockNumber: Number(evt.blockNumber || 0),
    description: (evt.description || '').trim(),
    id: (evt.id || '').trim(),
    timestamp: new Date(evt.timestamp).toISOString(),
    title: (evt.title || '').trim(),
    txHash: (evt.txHash || '').trim().toLowerCase(),
    type: evt.type,
  }));

  // Canonical Keccak-256 hash of the complete timeline events array
  const lifecycleEventsDigest = ethers.keccak256(
    ethers.toUtf8Bytes(JSON.stringify(canonicalEvents))
  );

  // Exact sorted canonical passport structure
  const canonicalRecord = {
    assetId: (obj.id || '').trim(),
    brand: (obj.brand || '').trim(),
    category: (obj.category || '').trim(),
    condition: (obj.condition || '').trim(),
    currentOwnerAddress: (obj.currentOwnerAddress || '').trim().toLowerCase(),
    description: (obj.description || '').trim(),
    lifecycleDigest: lifecycleEventsDigest,
    manufactureYear: Number(obj.manufactureYear || 0),
    model: (obj.model || '').trim(),
    name: (obj.name || '').trim(),
    orbitId: (obj.orbitId || '').trim(),
    recoveryRewardEth: Number(obj.recoveryRewardEth || 0).toFixed(4),
    registeredAt: new Date(obj.registeredAt || 0).toISOString(),
    serialHash: (obj.serialHash || '').trim().toLowerCase(),
    serialNumber: (obj.serialNumber || '').trim(),
    status: (obj.status || 'ACTIVE').trim(),
  };

  return JSON.stringify(canonicalRecord);
}

/**
 * Generates the authoritative Keccak-256 cryptographic passport hash.
 * Returns a 32-byte hex string (0x...) matching EVM bytes32 standards.
 */
export function computePassportHash(obj: PhysicalObject): string {
  const canonicalString = createCanonicalPassportPayload(obj);
  return ethers.keccak256(ethers.toUtf8Bytes(canonicalString));
}

/**
 * Checks whether the current passport data matches a given on-chain hash.
 */
export function verifyPassportDataMatch(obj: PhysicalObject, onChainHash: string): boolean {
  if (!onChainHash || onChainHash === ethers.ZeroHash) return false;
  const currentHash = computePassportHash(obj);
  return currentHash.toLowerCase() === onChainHash.toLowerCase();
}
