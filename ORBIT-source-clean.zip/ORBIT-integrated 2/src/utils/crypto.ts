/**
 * Lightweight cryptographic and formatting utilities for ORBIT Web3 simulation
 */

export function truncateAddress(address: string, start = 6, end = 4): string {
  if (!address) return '';
  if (address.length <= start + end) return address;
  return `${address.slice(0, start)}...${address.slice(-end)}`;
}

export function generateTxHash(): string {
  const chars = '0123456789abcdef';
  let hash = '0x';
  for (let i = 0; i < 64; i++) {
    hash += chars[Math.floor(Math.random() * chars.length)];
  }
  return hash;
}

export function generateOrbitId(existingNumbers: number[] = []): { orbitId: string; id: string; num: number } {
  let num = Math.floor(1000 + Math.random() * 9000);
  while (existingNumbers.includes(num)) {
    num = Math.floor(1000 + Math.random() * 9000);
  }
  return {
    orbitId: `ORBIT #${num}`,
    id: `orbit-${num}`,
    num,
  };
}

export async function computeSha256(text: string): Promise<string> {
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    try {
      const msgBuffer = new TextEncoder().encode(text);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      return `0x${hashHex.slice(0, 16)}...${hashHex.slice(-8)}`;
    } catch {
      // fallback
    }
  }
  // deterministic lightweight fallback
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash |= 0;
  }
  return `0x${Math.abs(hash).toString(16).padStart(12, 'a')}f8c4`;
}

export function generateHandshakeCode(orbitId: string): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let rand = '';
  for (let i = 0; i < 4; i++) {
    rand += chars[Math.floor(Math.random() * chars.length)];
  }
  const cleanId = orbitId.replace(/[^0-9]/g, '');
  return `REC-${cleanId || '7821'}-${rand}`;
}
